# Veri manipülasyonu ve CSV okuma işlemleri için pandas kütüphanesini içeri aktarıyoruz
import pandas as pd
# Grafik çizimi ve veri görselleştirme işlemleri için matplotlib kütüphanesini içeri aktarıyoruz
import matplotlib.pyplot as plt

# Veri ön işleme adımlarını tek bir çatı altında toplamak için sınıfımızı tanımlıyoruz
class DataPreprocessor:
    """
    Nesneye Yönelik Veri Ön İşleme ve Analiz Sınıfı.
    Bu sınıf, CSV formatındaki veri setlerini güvenli bir şekilde yükler,
    temizler, eksik verileri doldurur ve görselleştirir.
    """
    
    # Sınıftan bir nesne üretildiğinde otomatik olarak çalışan yapıcı (constructor) metodu tanımlıyoruz
    def _init_(self, dosya_yolu):
        """
        Yapıcı Metot: Veri setini okur ve private (gizli) attribute olarak saklar.
        """
        # Parametre olarak gelen CSV dosyasını okuyor ve çift alt çizgiyle private (gizli) değişkene atıyoruz
        self.__veri = pd.read_csv(dosya_yolu)
        # Verinin başarıyla yüklendiğini belirten bilgilendirme mesajını ekrana yazdırıyoruz
        print(f"Sistem: '{dosya_yolu}' dosyası başarıyla belleğe alındı.")

    # Veri setinin genel yapısını ve ilk analizini görmek için kullanacağımız metodu tanımlıyoruz
    def veri_ozeti(self):
        """
        Veri setinin ilk 5 satırını, teknik bilgilerini (info) ve istatistiksel özetini (describe) gösterir.
        """
        print("\n--- [VERİ ÖZETİ] ---")
        print("\n* İlk 5 Satır:")
        print(self.__veri.head())
        print("\n* Teknik Bilgiler (Sütun Tipleri ve Bellek):")
        self.__veri.info()
        print("\n* İstatistiksel Veriler (Sayısal Sütunlar):")
        print(self.__veri.describe())

    # Veri setinde eksik veri olup olmadığını kontrol etmek için kullanacağımız metodu tanımlıyoruz
    def eksik_veri_kontrolu(self):
        """
        Hangi sütunda kaç adet eksik veri (NaN) olduğunu hesaplar ve raporlar.
        """
        print("\n--- [EKSİK VERİ RAPORU] ---")
        eksikler = self.__veri.isnull().sum()
        print(eksikler)

    # Eksik (boş) verileri doldurmak amacıyla kullanacağımız metodu tanımlıyoruz
    def eksikleri_doldur(self, strateji='mean'):
        """
        Sayısal sütunlardaki eksik verileri seçilen stratejiye (mean veya median) göre güvenle doldurur.
        """
        # Yalnızca sayısal (float ve int) veri tipine sahip sütunların isimlerini seçiyoruz
        sayisal_sutunlar = self.__veri.select_dtypes(include=['float64', 'int64']).columns
        
        # Seçilen tüm sayısal sütunları tek tek dönmek için döngü başlatıyoruz
        for sutun in sayisal_sutunlar:
            # Eğer fonksiyona gönderilen strateji parametresi 'mean' (ortalama) ise bu bloğa giriyoruz
            if strateji == 'mean':
                # Hatalı değişken isimleri düzeltildi: self.__veri kullanılarak ortalama değer atanıyor
                self._veri[sutun] = self.veri[sutun].fillna(self._veri[sutun].mean())
            # Eğer fonksiyona gönderilen strateji parametresi 'median' (ortanca) ise bu bloğa giriyoruz
            elif strateji == 'median':
                # Hatalı değişken isimleri düzeltildi: self.__veri kullanılarak medyan değer atanıyor
                self._veri[sutun] = self.veri[sutun].fillna(self._veri[sutun].median())
        
        print(f"\nSistem: Sayısal sütunlardaki eksik veriler '{strateji}' ile tamamlandı.")

    # Analizde işimize yaramayacak olan gereksiz sütunları silen metodu tanımlıyoruz
    def sutun_sil(self, sutun_adi):
        """
        Veri setinden analize dahil edilmeyecek gereksiz veya işlevsiz bir sütunu kalıcı olarak siler.
        """
        if sutun_adi in self.__veri.columns:
            self.__veri.drop(columns=[sutun_adi], inplace=True)
            print(f"Sistem: '{sutun_adi}' sütunu başarıyla silindi.")
        else:
            print(f"Hata: '{sutun_adi}' adında bir sütun bulunamadı!")

    # İstenen sütunun verilerine göre uygun grafik çizen metodu tanımlıyoruz
    def dagilim_ciz(self, sutun_adi):
        """
        Belirtilen sütunun veri tipine göre otomatik olarak Histogram veya Bar Plot grafiği üretir.
        """
        if sutun_adi in self.__veri.columns:
            plt.figure(figsize=(10, 5))
            
            # Eğer hedef sütun nesne/metin (kategorik) bir veri ise bu bloğa giriyoruz
            if self.__veri[sutun_adi].dtype == 'object':
                self.__veri[sutun_adi].value_counts().head(10).plot(kind='bar', color='orange', edgecolor='black')
                plt.ylabel("Adet")
            # Eğer hedef sütun sayısal verilerden oluşuyorsa alternatif olarak bu bloğa giriyoruz
            else:
                self.__veri[sutun_adi].hist(bins=20, color='skyblue', edgecolor='black')
                plt.ylabel("Frekans")
            
            plt.title(f"{sutun_adi} Sütunu Dağılım Analizi")
            plt.xlabel(sutun_adi)
            plt.grid(axis='y', linestyle='--', alpha=0.7)
            plt.show()

    # Üzerinde temizlik ve değişiklik yapılan güncel veriyi kaydetme metodunu tanımlıyoruz
    def veriyi_kaydet(self, dosya_adi):
        """
        İşlenmiş ve temizlenmiş güncel veri setini dışarıya CSV dosyası olarak yazar.
        """
        self.__veri.to_csv(dosya_adi, index=False)
        print(f"Sistem: İşlenmiş veri '{dosya_adi}' olarak kaydedildi.")

    # Video Games veri setine özel olarak platform bazında küresel satışları inceleyen metodu tanımlıyoruz
    def platform_satis_analizi(self):
        """
        Video oyun veri setine özel: Büyük harf duyarlılığı düzeltilmiş Platform analizini yapar ve yeşil grafik çizer.
        """
        self._veri.columns = self._veri.columns.str.strip()
        
        # Hata düzeltildi: "platform" olan küçük harf, verideki aslı gibi "Platform" yapıldı
        sonuc = self.__veri.groupby("Platform")["Global_Sales"].sum().sort_values(ascending=False)
        print("\n--- [PLATFORM BAZLI TOPLAM SATIŞLAR (MİLYON)] ---")
        print(sonuc.head(10))
        
        sonuc.head(15).plot(kind='bar', figsize=(12, 6), color='green', edgecolor='black')
        plt.title("En Çok Satış Yapan 15 Oyun Platformu")
        plt.ylabel("Küresel Satış (Milyon $)")
        plt.show()